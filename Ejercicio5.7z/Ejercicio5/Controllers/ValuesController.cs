﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Ejercicio5.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<Alumnos>> Get()
        {
            var alumnos = new List <Alumnos>();
            var c1 = new Alumnos (42575456, "Carlos", 19);
            var c2 = new Alumnos (59625753,"Leonel", 24);
            var c3 = new Alumnos (48453234 , "Andres", 21);
            var c4 = new Alumnos (45753034 , "Ezequiel", 23);
            
            alumnos.Add(c1);
            alumnos.Add(c2);
            alumnos.Add(c3);
            alumnos.Add(c4);

            return alumnos.OrderBy(p=>p.dni).ToList();
        }
        
        // POST api/values
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }

        }
   

        public class Person
        {
            public int edad { get; set; }
            public string Nombre {get;set;}
            public void SetAge(int edad){
                this.edad = edad;
            }
        }

         public class Alumnos : Person
        {
            public int dni {get;set;}
            public Alumnos (int nota, string nombre, int edad)
            {
                this.dni = nota;
                this.Nombre = nombre;
                this.edad = edad;
            }
    }
}

